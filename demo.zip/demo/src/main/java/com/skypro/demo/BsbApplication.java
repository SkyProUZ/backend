package com.skypro.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BsbApplication {

	public static void main(String[] args) {
		SpringApplication.run(BsbApplication.class, args);
	}

}
